const express = require('express');
const router = express.Router();
const uuid = require('uuid');
const fs = require('fs');
const path = require('path');
// let users =require('../../Users');
let clients = undefined;

router.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, `index.html`));
});

router.get(`/Data/clients.json`, (req, res) => {
  res.sendFile(path.join(__dirname, '..', '..', `Data`, `clients.json`));

});
router.get(`/Data/questions.json`, (req, res) => {
  res.sendFile(path.join(__dirname, `Data`, `questions.json`));
});
router.get(`/main`, (req, res) => {
  res.sendFile(path.join(__dirname, `main.html`));

});

router.get(`/newkidadded.html`, (req, res) => {
  res.sendFile(path.join(__dirname, `newkidadded.html`));

});

router.get(`/quiz.html`, (req, res) => {
  res.sendFile(path.join(__dirname, `quiz.html`));

});

router.get(`/quizcomplete.html`, (req, res) => {
  res.sendFile(path.join(__dirname, `quizcomplete.html`));

});

router.get(`/kidinfo.html`, (req, res) => {

  fs.readFile(path.join(__dirname, '..', '..', `Data`, `clients.json`), (err, data) => {
    if (err) throw err;
    clients = JSON.parse(data);
    //console.log(clients);

  });
  console.log(req.query.id);
  clients.forEach(client => {
    if (client.id == req.query.id) {
      client.kid.age = calAge(client.kid.brith);
      client.kid.month = calMonth(client.kid.brith, client.kid.age);
      console.log(client.kid.month);
    }
  });
  let new_data = JSON.stringify(clients);
  fs.writeFile(path.join(__dirname, '..', '..', `Data`, `clients.json`), new_data, (err) => {
    if (err) throw err;
    console.log(`update user to json file....`);
  });
  res.sendFile(path.join(__dirname, `kidinfo.html`));

});

/*////////////////////////////////////////////////post////////////////////////////////////*/
router.post(`/delete`, (req, res) => {
  console.log("delete");

  fs.readFile(path.join(__dirname, '..', '..', `Data`, `clients.json`), (err, data) => {
    if (err) throw err;
    clients = JSON.parse(data);
    console.log(req.body);
    var deleteIndex;
    var id = req.body.id;
    clients.forEach((client, index) => {
      if (client.id == id) {
        deleteIndex=index;

      }
    });
    clients.splice(deleteIndex, 1);
    //console.log(clients);
    let new_data = JSON.stringify(clients);
    fs.writeFile(path.join(__dirname, '..', '..', `Data`, `clients.json`), new_data, (err) => {
      if (err) throw err;
      console.log(`update clients to json file....`);
    });
    
  });

  res.end();

});

router.post(`/reset`, (req, res) => {
  console.log("reset");
  fs.readFile(path.join(__dirname, '..', '..', `Data`, `clients.json`), (err, data) => {
    if (err) throw err;
    clients = JSON.parse(data);
  });
  console.log(req.body);
  var id = req.body.id;
  clients.forEach(client => {

    if (client.id == id) {
      client.kid.data.GM = 0;
      client.kid.data.FM = 0;
      client.kid.data.RL = 0;
      client.kid.data.EL = 0;
      client.kid.data.PS = 0;
      client.kid.data.maxpoint = 0;
    }
  });

  //console.log(clients);
  let new_data = JSON.stringify(clients);
  fs.writeFile(path.join(__dirname, '..', '..', `Data`, `clients.json`), new_data, (err) => {
    if (err) throw err;
    console.log(`update clients to json file....`);
  });
  res.end();

});

router.post(`/reKidData`, (req, res) => {

  fs.readFile(path.join(__dirname, '..', '..', `Data`, `clients.json`), (err, data) => {
    if (err) throw err;
    clients = JSON.parse(data);
    //console.log(clients);
    newData = req.body;
    console.log(newData);
    clients.forEach(client => {
      if (client.id == newData.id) {
        client.kid.data.GM = newData.GM;
        client.kid.data.FM = newData.FM;
        client.kid.data.RL = newData.RL;
        client.kid.data.EL = newData.EL;
        client.kid.data.PS = newData.PS;
        client.kid.data.maxpoint = newData.maxpoint;
      }
    });

    let new_data = JSON.stringify(clients);
    fs.writeFile(path.join(__dirname, '..', '..', `Data`, `clients.json`), new_data, (err) => {
      if (err) throw err;
      console.log(`update clients to json file....`);
    });
    res.end();
  });

});

router.post(`/creNewKid`, (req, res) => {
  //res.send(`<h1>hello World</h1>`)
  // console.log(req.client);
  newClient = req.body;

  fs.readFile(path.join(__dirname, '..', '..', `Data`, `clients.json`), (err, data) => {
    if (err) throw err;
    clients = JSON.parse(data);
    //console.log(clients);


  var client = {
    "id": "",
    "username": "",
    "password": "",
    "address": "",
    "parent": {
      "firstname": "",
      "lastname": "",
      "gender": " ",
      "identity": " ",
    },
    "phone": " ",
    "email": " ",
    "kid": {
      "firstname": " ",
      "lastname": " ",
      "nickname": "",
      "brith": "",
      "gender": " ",
      "age": " ",
      "month": " ",
      "data": {
        "maxpoint": 0,
        "GM": 0,
        "FM": 0,
        "RL": 0,
        "EL": 0,
        "PS": 0
      }
    }
  };

  /* let i=0;
    while(clients[parseInt(i)] != null)
    {
      i++;
    }*/
  if (clients.length > 0) {
    client.id = clients[clients.length - 1].id + 1;
  }
  else {
    client.id = 1;
  }
  client.username = newClient.username;
  client.password = newClient.password;
  client.address = newClient.address;
  client.parent.firstname = newClient.parentfirstname;
  client.parent.lastname = newClient.parentlastname;
  client.parent.gender = newClient.parentgender;
  client.parent.identity = newClient.parentidentity;
  client.phone = newClient.phone;
  client.email = newClient.email;
  client.kid.firstname = newClient.kidfirstname;
  client.kid.lastname = newClient.kidlastname;
  client.kid.nickname = newClient.kidnickname;
  client.kid.brith = newClient.kidbrith;
  client.kid.gender = newClient.kidgender;
  client.kid.age = newClient.kidage;
  client.kid.month = calMonth(client.kid.brith, client.kid.age);
  console.log(client.kid.month);
  clients.push(client);
  // console.log('redirect');
  //res.redirect('/newkidadded.html')

  let new_data = JSON.stringify(clients);
  fs.writeFile(path.join(__dirname, '..', '..', `Data`, `clients.json`), new_data, (err) => {
    if (err) throw err;
    console.log(`update user to json file....`);
  });
});
  res.end();


});

router.post(`/editkid`, (req, res) => {

  newClient = req.body;

  fs.readFile(path.join(__dirname, '..', '..', `Data`, `clients.json`), (err, data) => {
    if (err) throw err;
    clients = JSON.parse(data);
    clients.forEach(client => {

      if (client.id == newClient.id) {
        client.username = newClient.username;
        client.password = newClient.password;
        client.address = newClient.address;
        client.parent.firstname = newClient.parentfirstname;
        client.parent.lastname = newClient.parentlastname;
        client.parent.gender = newClient.parentgender;
        client.parent.identity = newClient.parentidentity;
        client.phone = newClient.phone;
        client.email = newClient.email;
        client.kid.firstname = newClient.kidfirstname;
        client.kid.lastname = newClient.kidlastname;
        client.kid.nickname = newClient.kidnickname;
        client.kid.brith = newClient.kidbrith;
        client.kid.gender = newClient.kidgender;
        client.kid.age = newClient.kidage;
        client.kid.month = calMonth(client.kid.brith, client.kid.age);
        console.log(client.kid.month);
        clients.push(client);
        let new_data = JSON.stringify(clients);
        fs.writeFile(path.join(__dirname, '..', '..', `Data`, `clients.json`), new_data, (err) => {
          if (err) throw err;
          console.log(`update user to json file....`);
        });
  
      }
    });

  });
 

  res.end();


});



function calMonth(brith, age) {
  var curDate = new Date();
  var birth_date = new Date(brith);

  var month = age * 12;
  month += curDate.getMonth() - birth_date.getMonth();
  return month;
}
function calAge(brith) {
  var curDate = new Date();
  var birth_date = new Date(brith);
  /* var age = (curDate - birth_date)/(1000*60*60*24*365);
   ageInput.value=Math.floor(age);
   console.log(age);*/
  var age = curDate.getFullYear() - birth_date.getFullYear();
  if (curDate.getMonth() < birth_date.getMonth()) {
    age--;
  }
  else if (curDate.getMonth() === birth_date.getMonth()) {
    console.log(birth_date.getDate() + '/' + curDate.getDate());
    if (curDate.getDate() < birth_date.getDate()) {
      age--;
    }
  }
  return age;
}


module.exports = router;
