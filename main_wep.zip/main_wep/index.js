const express = require('express');
const path = require('path');
const app = express();
const fs = require('fs');
const readline = require('readline');
const url = require('url');
const ejs = require('ejs');
const multer = require('multer');
const PORT = process.env.PORT || 9000;
let clients = undefined;

app.set('view engine','ejs');
app.use(express.static(path.join(__dirname)));

app.get(`/`, (req, res) => {
 res.sendFile(path.join(__dirname, `index.html`));

});

//body parser
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(require(`./routes/api/logger`));
app.use(`/`,require(`./routes/api/users`));

// app.get(`/Data/clients.json`, (req, res) => {
//   res.sendFile(path.join(__dirname, `Data`, `clients.json`));

// });
// app.get(`/Data/questions.json`, (req, res) => {
//   res.sendFile(path.join(__dirname, `Data`, `questions.json`));
// });
// app.get(`/main`, (req, res) => {
//   res.sendFile(path.join(__dirname, `main.html`));

// });

// app.get(`/newkidadded`, (req, res) => {
//   res.sendFile(path.join(__dirname, `newkidadded.html`));

// });

// app.get(`/quiz`, (req, res) => {
//   res.sendFile(path.join(__dirname, `quiz.html`));

// });

// app.get(`/quizcomplete`, (req, res) => {
//   res.sendFile(path.join(__dirname, `quizcomplete.html`));

// });

// app.get(`/kidinfo`, (req, res) => {

//   fs.readFile(path.join(__dirname, `Data`, `clients.json`), (err, data) => {
//     if (err) throw err;
//     clients = JSON.parse(data);
//     //console.log(clients);

//   });
//   console.log(req.query.id);
//   clients.forEach(client => {
//     if (client.id == req.query.id) {
//       client.kid.age = calAge(client.kid.brith);
//       client.kid.month = calMonth(client.kid.brith, client.kid.age);
//       console.log(client.kid.month);
//     } 
//   });
//   let new_data = JSON.stringify(clients);
//   fs.writeFile(path.join(__dirname, `Data`, `clients.json`), new_data, (err) => {
//     if (err) throw err;
//     console.log(`update user to json file....`);
//   });
//   res.sendFile(path.join(__dirname,`kidinfo.html`));

// });

// /*////////////////////////////////////////////////post////////////////////////////////////*/
// app.post(`/delete`, (req, res) => {
//   console.log("delete");

//   fs.readFile(path.join(__dirname, `Data`, `clients.json`), (err, data) => {
//     if (err) throw err;
//     clients = JSON.parse(data);
//   });
//     console.log(req.body);
//     var deleteIndex;
//     var id= req.body.id;
//     clients.forEach((client,index)=>{
//       if(client.id==id)
//       {
//         deleteIndex=index;
//       }
//     });
//     clients.splice( deleteIndex, deleteIndex);
//     //console.log(clients);
//     let new_data = JSON.stringify(clients);
//   fs.writeFile(path.join(__dirname, `Data`, `clients.json`), new_data, (err) => {
//     if (err) throw err;
//     console.log(`update clients to json file....`);
//   });
//   res.end();

// });

// app.post(`/reset`, (req, res) => {
//   console.log("reset");
//   fs.readFile(path.join(__dirname, `Data`, `clients.json`), (err, data) => {
//     if (err) throw err;
//     clients = JSON.parse(data);
//   });
//   console.log(req.body);
//   var id= req.body.id;
//     clients.forEach(client=>{

//       if(client.id==id)
//       {
//         client.kid.data.GM = 0;
//         client.kid.data.FM = 0;
//         client.kid.data.RL = 0;
//         client.kid.data.EL = 0;
//         client.kid.data.PS = 0;
//         client.kid.data.maxpoint = 0;
//       }
//     });
    
//     //console.log(clients);
//     let new_data = JSON.stringify(clients);
//     fs.writeFile(path.join(__dirname, `Data`, `clients.json`), new_data, (err) => {
//       if (err) throw err;
//       console.log(`update clients to json file....`);
//     });
//     res.end();

// });

// app.post(`/reKidData`, (req, res) => {

//   fs.readFile(path.join(__dirname, `Data`, `clients.json`), (err, data) => {
//     if (err) throw err;
//     clients = JSON.parse(data);
//     //console.log(clients);
//   });
//   newData= req.body;
//   console.log( newData);
//   clients.forEach(client=>{
//     if(client.id==newData.id)
//     {
//       client.kid.data.GM = newData.GM;
//       client.kid.data.FM = newData.FM;
//       client.kid.data.RL = newData.RL;
//       client.kid.data.EL = newData.EL;
//       client.kid.data.PS = newData.PS;
//       client.kid.data.maxpoint = newData.maxpoint;
//     }
//   });

//   let new_data = JSON.stringify(clients);
//   fs.writeFile(path.join(__dirname, `Data`, `clients.json`), new_data, (err) => {
//     if (err) throw err;
//     console.log(`update clients to json file....`);
//   });
//   res.end();
// });

// app.post(`/creNewKid`, (req, res) => {
//   //res.send(`<h1>hello World</h1>`)
//   // console.log(req.client);
//   newClient = req.body;

//   fs.readFile(path.join(__dirname, `Data`, `clients.json`), (err, data) => {
//     if (err) throw err;
//     clients = JSON.parse(data);
//     //console.log(clients);
//   });

//   var client = {
//     "id": "",
//     "username": "",
//     "password": "",
//     "address": "",
//     "parent": {
//       "firstname": "",
//       "lastname": "",
//       "gender": " ",
//       "identity": " ",
//     },
//     "phone": " ",
//     "email": " ",
//     "kid": {
//       "firstname": " ",
//       "lastname": " ",
//       "nickname": "",
//       "brith": "",
//       "gender": " ",
//       "age": " ",
//       "month": " ",
//       "data": {
//         "maxpoint":0,
//         "GM": 0,
//         "FM": 0,
//         "RL": 0,
//         "EL": 0,
//         "PS": 0
//       }
//     }
//   };
//   console.log("5555555");
//   console.log(newClient.imgflie);
//   /* let i=0;
//     while(clients[parseInt(i)] != null)
//     {
//       i++;
//     }*/
//   if (clients.length > 0) {
//     client.id = clients[clients.length - 1].id + 1;
//   }
//   else {
//     client.id = 1;
//   }
//   client.username = newClient.username;
//   client.password = newClient.password;
//   client.address = newClient.address;
//   client.parent.firstname = newClient.parentfirstname;
//   client.parent.lastname = newClient.parentlastname;
//   client.parent.gender = newClient.parentgender;
//   client.parent.identity = newClient.parentidentity;
//   client.phone = newClient.phone;
//   client.email = newClient.email;
//   client.kid.firstname = newClient.kidfirstname;
//   client.kid.lastname = newClient.kidlastname;
//   client.kid.nickname = newClient.kidnickname;
//   client.kid.brith = newClient.kidbrith;
//   client.kid.gender = newClient.kidgender;
//   client.kid.age = newClient.kidage;
//   client.kid.month = calMonth(client.kid.brith, client.kid.age);
//   console.log(client.kid.month);
//   clients.push(client);
//   // console.log('redirect');
//   //res.redirect('/newkidadded.html')

//   let new_data = JSON.stringify(clients);
//   fs.writeFile(path.join(__dirname, `Data`, `clients.json`), new_data, (err) => {
//     if (err) throw err;
//     console.log(`update user to json file....`);
//   });
//   res.end();


// });



app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
  fs.readFile(path.join(__dirname, `Data`, `clients.json`), (err, data) => {
    if (err) throw err;
    clients = JSON.parse(data);
  });
  {
    /*  var myInterface = readline.createInterface({
        input: fs.createReadStream(path.join(__dirname,`Data`,`question.txt`))
      });
  
//       var lineno = 0;
//       var linedata = 0;
//       var questions=[];
//       var quizAge = {
//           "age":"",
//           "GM":[
//           ],
//           "FM":[
  
//           ],
//           "RL":[
  
//           ],
//           "EL":[
  
//           ],
//           "PS":[
  
//           ]
  
//       }
//       var quizdata ={
//         "tag":"",
//         "text":"",
//         "guide":"false",
//         "tools":[]
//       }
//       myInterface.on('line', function (line) {
//         lineno++;
//         if(Number.isInteger(parseInt(line)))
//         {
//             if(quizAge.age != "y"){
//               questions.push(quizAge);
//               console.log(lineno);
//               console.log(questions);
//               if(lineno ==368)
//               { 
//                 let new_data = JSON.stringify(questions);
//                fs.writeFile(path.join(__dirname,`Data`,`questions.json`),new_data,(err)=>{
//                    if(err) throw err;
//                    console.log(`update user to json file....`);
//                });
//              }
//             }
//             quizAge =  {
//               "age":line,
//               "GM":[
//               ],
//               "FM":[
      
//               ],
//               "RL":[
      
//               ],
//               "EL":[
      
//               ],
//               "PS":[
      
//               ]
//           }
//         }
//         else
//         {
//           if( linedata == 3)
//           {
//             linedata = 0;
//             quizdata ={
//               "tag":"",
//               "text":"",
//               "guide":"false",
//               "tools":[]
//             }
//           }
  
//           if(linedata == 0){
//             var tag = line.split(' ');
//             quizdata.tag = tag[0];
//             if(tag.length > 1) quizdata.guide = "true";
//           }
//           else if(linedata == 1){
//             quizdata.text =line;
//           }
//           else if(linedata == 2){
//             var tools = line.split('/');
//             for(var i=0;i< tools.length;i++){
//               if(tools[i] !="") quizdata.tools.push(tools[i]);
//             }
//             switch(quizdata.tag)
//             {
//               case "GM":
//                quizAge.GM.push(quizdata);
//               break;
//               case "FM":
//                quizAge.FM.push(quizdata);
//               break;
//               case "RL":
//                quizAge.RL.push(quizdata);
//               break;
//               case "EL":
//                quizAge.EL.push(quizdata);
//               break;
//               case "PS":
//                quizAge.PS.push(quizdata);
//               break;
//             }
//           }  
//           linedata++;
          
//         }
//       });
//       //if(quizAge.age != undefined)questions.push(quizAge);
//       //console.log(questions);*/
  }
});

// function calMonth(brith, age) {
//   var curDate = new Date();
//   var birth_date = new Date(brith);

//   var month = age * 12;
//   month += curDate.getMonth() - birth_date.getMonth();
//   return month;
// }
// function calAge(brith) {
//   var curDate = new Date();
//   var birth_date = new Date(brith);
//   /* var age = (curDate - birth_date)/(1000*60*60*24*365);
//    ageInput.value=Math.floor(age);
//    console.log(age);*/
//   var age = curDate.getFullYear() - birth_date.getFullYear();
//   if (curDate.getMonth() < birth_date.getMonth()) {
//     age--;
//   }
//   else if (curDate.getMonth() === birth_date.getMonth()) {
//     console.log(birth_date.getDate() + '/' + curDate.getDate());
//     if (curDate.getDate() < birth_date.getDate()) {
//       age--;
//     }
//   }
//   return age;
// }