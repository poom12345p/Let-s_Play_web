var ctx = document.getElementById('myChart').getContext('2d');
var quizbtn=  document.getElementById('quiz-btn');
var urlParams = new URLSearchParams(location.search);


var chart = new Chart(ctx, {
    // The type of chart we want to create
    type: 'radar',

    // The data for our dataset
    data: {
        labels: ['GM', 'FM', 'RL', 'EL', 'PS'],
        datasets: [{
            borderCapStyle:'',
            label: '',
            backgroundColor: '',
            borderColor: 'rgba(255, 99, 132)',
            data: [70, 60, 50, 85, 60]
        }]
    },

    // Configuration options go here
    options: {
      scale:{
            ticks:{
                display:false,
                beginAtZero: true,
                suggestedMax: 100,
                precision: 0,
                stepSize: 10
            },
            pointLabels: {
                fontSize: 20,
            },
            gridLines: 
            { 
                color: "#131c2b" 
            }
        },
        legend: {
            display:false,  
      }
    }   
});

function changeData(GM, FM, RL, EL, PS){
    chart.data.datasets[0].data[0]=GM;
    chart.data.datasets[0].data[1]=FM;
    chart.data.datasets[0].data[2]=RL;
    chart.data.datasets[0].data[3]=EL;
    chart.data.datasets[0].data[4]=PS;
    chart.update();

}

function fetclientData()
{
  console.log(urlParams.get('id'));
  var myID =urlParams.get('id');
  fetch(`../Data/clients.json`) 
  .then(res =>res.json())
  .then(data=>{
      
    var myClient  =data.filter(client =>
        client.id == myID
      );
      console.log(data);
     // myClient =JSON.parse(myClient);
    changeData(myClient[0].kid.data.GM, myClient[0].kid.data.FM, myClient[0].kid.data.RL, myClient[0].kid.data.EL, myClient[0].kid.data.PS);
        console.log(myClient[0]);

        document.querySelector('#kid-nickname').innerHTML =myClient[0].kid.nickname;
        document.querySelector('#kid-firstname').innerHTML =myClient[0].kid.firstname;
        document.querySelector('#kid-lastname').innerHTML =myClient[0].kid.lastname;
        document.querySelector('#kid-dob').innerHTML =myClient[0].kid.brith;
        document.querySelector('#kid-age').innerHTML =myClient[0].kid.age +'ปี';
        document.querySelector('#parent-firstname').innerHTML =myClient[0].parent.firstname;
        document.querySelector('#parent-lastname').innerHTML =myClient[0].parent.lastname;
        document.querySelector('#email').innerHTML =myClient[0].email;
        document.querySelector('#phone').innerHTML =myClient[0].phone;
        document.querySelector('#address').innerHTML =myClient[0].address;
        var id=myClient[0].id;
        var month =myClient[0].kid.month;
        quizbtn.href=`quiz.html?id=${id}&month=${month}`;
  });
 
}

$(document).ready(function(){

    $("#reset-btn").click(function(){
        var resetID={ "id":urlParams.get('id')};
      $.post(location.origin+"/reset",resetID, function(data){
        
      });
      location.reload();
    });

    $("#edit-btn").click(function(){
     // var resetID={ "id":urlParams.get('id')};
     var myID =urlParams.get('id');
      location.replace(location.origin + `/editkid.html?id=${myID}`);
  });

    $("#delete-btn").click(function(){
 
        var deleteID={ "id":urlParams.get('id')};
      $.post(location.origin+"/delete", deleteID, function(data){
        
      });
    });
  });