var myimg = document.querySelector('#blah');
myimg.style.visibility = "hidden";

function readURL(input) {
    if (input.files && input.files[0]) {
      var reader = new FileReader();
      console.log(input.files);
      reader.onload = function(e) {
        $('#blah').attr('src', e.target.result);
      }
      
      reader.readAsDataURL(input.files[0]);
      myimg.style.visibility = "visible";
    }
  }
  
  $("#imgInp").change(function() {
      console.log("imgchange");
    readURL(this);
  });