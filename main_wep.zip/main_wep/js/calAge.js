var dateInput = document.querySelector('#kid-dob');
var ageInput = document.querySelector('#kid-age');
dateInput.addEventListener('change', calAge);
function calAge() {
   var curDate = new Date();
   var birth_date = new Date(dateInput.value);
   /* var age = (curDate - birth_date)/(1000*60*60*24*365);
    ageInput.value=Math.floor(age);
    console.log(age);*/
   var age = curDate.getFullYear() - birth_date.getFullYear();
   if (curDate.getMonth() < birth_date.getMonth()) {
      age--;
   }
   else if (curDate.getMonth() === birth_date.getMonth()) {
      console.log(birth_date.getDate() + '/' + curDate.getDate());
      if (curDate.getDate() < birth_date.getDate()) {
         age--;
      }
   }
   ageInput.value = age;
}