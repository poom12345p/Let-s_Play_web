parentMaleCheck=document.querySelector("#parent-gender-male");
parentFemaleCheck=document.querySelector("#parent-gender-female");
kidMaleCheck=document.querySelector("#kid-gender-male");
kidFemaleCheck=document.querySelector("#kid-gender-female");
var cautiontag =document.querySelector("#caution");
var cautiontext =document.querySelector("#cautiontext");
cautiontag.style.visibility = "hidden";
var urlParams = new URLSearchParams(location.search);
//////////////
var parentfirstname=document.querySelector("#parent-firstname");
var parentlastname=document.querySelector("#parent-lastname");
var parentid=document.querySelector("#parent-id");
var myemail=document.querySelector("#email");
var mypas=document.querySelector("#password");
var myrepas=document.querySelector("#re-password");
var myphone = document.querySelector("#phone");
var myadress = document.querySelector("#address");
var kidfirstname=document.querySelector("#kid-firstname");
var kidlastname=document.querySelector("#kid-lastname");
var kidnickname=document.querySelector("#kid-nickname");
var kidbrithday=document.querySelector("#kid-dob");
var kidage=document.querySelector("#kid-age");
//////////////
//var myimg = document.querySelector('#blah');
//console.log(myimg);
parentMaleCheck.addEventListener ("change", CheckParentMale);
parentFemaleCheck.addEventListener ("change", CheckParentFemale);
kidMaleCheck.addEventListener ("change", CheckKidMale);
kidFemaleCheck.addEventListener ("change",CheckKidFemale);
console.log(location);
 console.log(location.host);
function CheckParentMale(event){
  if(parentMaleCheck.checked)
  parentFemaleCheck.checked=false;
  console.log("CheckParentMale");
}
function CheckParentFemale(event){
  if(parentFemaleCheck.checked)
  parentMaleCheck.checked= false;
}
function CheckKidFemale(event){
  if(kidFemaleCheck.checked)
  kidMaleCheck.checked =false;
}
function CheckKidMale(event){
  if(kidMaleCheck.checked)
  kidFemaleCheck.checked =false;
}

function fillinfo()
{
    fetch(`../Data/clients.json`) 
    .then(res =>res.json())
    .then(data=>{
        var myID =urlParams.get('id');
        var myClient  =data.filter(client =>
            client.id == myID
          );
          console.log(myClient);
          parentfirstname.value=myClient[0].parent.firstname;
          console.log(parentfirstname);
          console.log(myClient[0].parent.firstname);
          parentlastname.value=myClient[0].parent.lastname;
          parentid.value=myClient[0].parent.identity;
          myemail.value=myClient[0].email;
          myadress.value=myClient[0].address;
          mypas.value=myClient[0].password;
          myrepas.value=myClient[0].password;
          myphone.value=myClient[0].phone;
          kidlastname.value=myClient[0].kid.lastname;
          kidfirstname.value=myClient[0].kid.firstname;
          kidnickname.value=myClient[0].kid.nickname;
          kidbrithday.value=myClient[0].kid.brith;
          kidage.value=myClient[0].kid.age;
          switch(myClient[0].parent.gender)
          {
              case "หญิง":
                  parentFemaleCheck.checked = true;
              break;
              case "ชาย":
                  parentMaleCheck.checked = true;
              break;
          }

          switch(myClient[0].kid.gender)
          {
              case "หญิง":
                  kidFemaleCheck.checked = true;
              break;
              case "ชาย":
                  kidMaleCheck.checked= true;
              break;
          }

    });
}


$(document).ready(function(){
    var client={
      "id":"",
      "username":"",
      "password":"",
      "address":"",
      "parentfirstname": "",
      "parentlastname": "",
      "parentgender": " ",
      "parentidentity": " ",
      "phone": " ",
      "email": " ",
      "kidfirstname": " ",
      "kidlastname": " ",
      "kidnickname": " ",
      "kidbrith":"",
      "kidgender": " ",
      "kidage": " ",
      "GM":"",
      "FM":"",
      "RL":"",
      "EL":"",
      "PS":"",
      "imgfile":""
    };

   
    $("#submit").click(function(){
      client.id =urlParams.get('id');

      var caution="กรุณากรอก ";
      var pid=$("#parent-id").val();

      //var isOK=ture;
      if($("#email").val()=="") caution +="Email,";
      if($("#phone").val()=="") caution +="หมายเลขโทรศัพท์,";
      if($("#password").val()=="") caution +="password,";
      if($("#password").val()!= $("#re-password").val()) caution +="ยืนยันpasswordให้ตรงกัน,";
      if($("#parent-firstname").val()=="") caution +="ชื่อจริงผู้ปกครองม,";
      if($("#parent-lastname").val()=="") caution +="นามสกุลผู้ปกครอง,";
      if(pid.length <13) caution +="เลขบัตรประชาชน,";
      if($("#kid-firstname").val()=="") caution +="ชื่อเด็ก,";
      if($("#kid-lastname").val()=="") caution +="นามสกุลเด็ก,";
      if($("#kid-nickname").val()=="") caution +="ชื่อเล่นเด็ก,";
      if($("#kid-age").val()=="") caution +="วันเกิดเด็ก,";
      if(caution=="กรุณากรอก ")
      {
        client.username=$("#email").val();
        client.password=$("#password").val();
        client.email=$("#email").val();
        client.parentfirstname=$("#parent-firstname").val();
        client.parentlastname=$("#parent-lastname").val();
        if(document.querySelector("#parent-gender-male").checked){
            client.parentgender='ชาย';
        }
        else if(document.querySelector("#parent-gender-female").checked){
          client.parentgender='หญิง';
        }
        client.phone=$("#phone").val();
        client.parentidentity=$("#parent-id").val();
        client.address=$("#address").val();
        client.kidfirstname=$("#kid-firstname").val();
        client.kidlastname=$("#kid-lastname").val();
        client.kidnickname=$("#kid-nickname").val();
        //client.imgfile = myimg.src;
        console.log( client.imgfile);
        if(document.querySelector("#kid-gender-male").checked){
          client.kidgender='ชาย';
        }
        else if(document.querySelector("#kid-gender-female").checked){
          client.kidgender='หญิง';
        }
        client.kidbrith=$("#kid-dob").val();
        client.kidage=$("#kid-age").val();

        $.post(location.origin+"/editkid",client, function(data){
          if(data==='done')
            {
              alert("login success");
            }
        });
        location.replace(location.origin + `/kidinfo.html?id=${client.id}`)
      }
      else
      {
        cautiontag.style.visibility = "visible";
        cautiontext.innerHTML =caution;
        console.log(caution);
      }
    });
  });