var questionText = document.querySelector('#questionText');
var toolslist = document.querySelector('#toolslist');
var videoscreen= document.querySelector('#video');
console.log(videoscreen);
console.log(toolslist);
//var YESbtn = document.querySelector('#YES-btn');
//var NObtn = document.querySelector('#NO-btn');
var urlParams = new URLSearchParams(location.search);
var curMaxPoint = 0, maxpoint = 0, curGM = 0, curFM = 0, curRL = 0, curEL = 0, curPS = 0;
var questionlist = [];
var quizdatalist= [];
var curQuestion;
var questions;
var curlistlenght=0;
var isComplete = false;
var curIndex=-1;
var isClicked=false;
$(document).ready(function () {
    $("#prebtn").click(function (event) {
        event.preventDefault();
        if(!isClicked &&  quizdatalist.length>0)
        {
            questionText.innerHTML ="กำลังโหลด...";
            isClicked =true;
            curIndex-=2;
            var l=quizdatalist.length;
            var qd=quizdatalist[l-1];
            questionlist.splice(qd.maxlenght,qd.maxlenght-questionlist.length);
            curGM =qd.GM;
            curFM =qd.FM;
            curRL =qd.RL;
            curEL =qd.EL;
            curPS =qd.PS;
            quizdatalist.splice(l-1,1);
            changeQuestion();
            
        }
    });

    $("#YES-btn").click(function (event) {
        event.preventDefault();
        questionText.innerHTML ="กำลังโหลด...";
        /*if(!isComplete){
            switch (curQuestion.question.tag) {
                case "GM":
                    curGM = parseInt(curGM) + parseInt(curQuestion.point);
                    break;
                case "FM":
                    curFM = parseInt(curFM) + parseInt(curQuestion.point);
                    break;
                case "RL":
                    curRL = parseInt(curRL) + parseInt(curQuestion.point);
                    break;
                case "EL":
                    curEL = parseInt(curEL) + parseInt(curQuestion.point);
                    break;
                case "PS":
                    curPS = parseInt(curPS) + parseInt(curQuestion.point);
                    break;
            }
        }*/
        if(!isClicked)
        {
            isClicked=true;
            addQuizData();
            changeQuestion();
        }
    });

    $("#NO-btn").click(function (event) {
        event.preventDefault();
        questionText.innerHTML ="กำลังโหลด...";
        if(!isClicked)
        {
            isClicked=true;
            addQuizData();
            switch (curQuestion.question.tag) {
                case "GM":
                    curGM = parseInt(curGM) - parseInt(curQuestion.point);
                    break;
                case "FM":
                    curFM = parseInt(curFM) - parseInt(curQuestion.point);
                    break;
                case "RL":
                    curRL = parseInt(curRL) - parseInt(curQuestion.point);
                    break;
                case "EL":
                    curEL = parseInt(curEL) - parseInt(curQuestion.point);
                    break;
                case "PS":
                    curPS = parseInt(curPS) - parseInt(curQuestion.point);
                    break;
            }
           // curlistlenght=questionlist.length;
            pushAllquestion(curQuestion.question.tag, curQuestion.index - 1);
            console.log(questionlist);
            
            changeQuestion();
        }
    });
});
/*YESbtn.addEventListener('click', clickYES);
NObtn.addEventListener('click', clickNO);
function clickYES(event) {
    event.preventDefault();
    if(!isComplete){
        switch (curQuestion.question.tag) {
            case "GM":
                curGM = parseInt(curGM) + parseInt(curQuestion.point);
                break;
            case "FM":
                curFM = parseInt(curFM) + parseInt(curQuestion.point);
                break;
            case "RL":
                curRL = parseInt(curRL) + parseInt(curQuestion.point);
                break;
            case "EL":
                curEL = parseInt(curEL) + parseInt(curQuestion.point);
                break;
            case "PS":
                curPS = parseInt(curPS) + parseInt(curQuestion.point);
                break;
        }
    }
    
    changeQuestion();

}
function clickNO(event) {
    event.preventDefault();
    pushAllquestion(curQuestion.question.tag, curQuestion.index - 1);
    console.log(questionlist);
    changeQuestion();


}*/
function addQuizData()
{
    var quizdata={
        "maxlenght":questionlist.length,
        "GM":curGM,
        "FM":curFM,
        "RL":curRL,
        "EL":curEL,
        "PS":curPS
    }
    quizdatalist.push(quizdata);

}


console.log(questionText);
function changeQuestion() {
    /*fetch(`../Data/questions.json`)
        .then(res => res.json())
        .then(data => {
            console.log(data[0].GM[0].text);
            questionText.innerHTML = data[0].GM[0].text;
        })
        .catch(err => console.log(err));*/
        console.log(curIndex);
    console.log("GM-" + curGM + "|" + "FM-" + curFM + "|" + "RL-" + curRL + "|" + "EL-" + curEL + "|" + "PS-" + curPS + "|");
    curIndex++;
    if(curIndex < questionlist.length )
    {
       
        curQuestion = questionlist[curIndex];
        questionText.innerHTML = curQuestion.question.text;
        videoscreen.src = curQuestion.question.video;
        toolslist.innerHTML="";
        for(var i=0 ;i<curQuestion.question.tools.length;i++)
        {
            toolslist.innerHTML+=`<li>
            <p class="mb-1 h5 font-italic lineheight1-5">${curQuestion.question.tools[i]}</p>
          </li>`
        }
        if( toolslist.innerHTML=="")
        {
            toolslist.innerHTML+=`<li>
            <p class="mb-1 h5 font-italic lineheight1-5">ไม่มี</p>
          </li>`
        }
        isClicked=false;
    }
  /*  if (questionlist.length > 0) {
        curQuestion = questionlist[0];
        //questionlist.shift();
        questionText.innerHTML = curQuestion.question.text;
    }*/
    else {
        isComplete = true;
        var myID = urlParams.get('id');
        location.replace(location.origin + `/quizcomplete.html?id=${myID}`);
        var newData = {
            "id": myID,
            "maxpoint":curMaxPoint,
            "GM": (curGM * 100) / curMaxPoint,
            "FM": (curFM * 100) / curMaxPoint,
            "RL": (curRL * 100) / curMaxPoint,
            "EL": (curEL * 100) / curMaxPoint,
            "PS": (curPS * 100) / curMaxPoint
        }
        $.post(location.origin + "/reKidData", newData, function (data) {

        });
    }
}

var mymonth = parseInt(urlParams.get('month'));
console.log(mymonth);

function createQuestionList() {
    fetch(`../Data/questions.json`)
        .then(res => res.json())
        .then(data => {
            var p = 0;
            console.log(data);
            questions = data;
            for (p = 0; p <= data.length; p++) {
               if(p< data.length) console.log(data[p].month);
                if (p === data.length ||parseInt(data[p].month) > mymonth) {
                    console.log(`p= ` + p);
                    curMaxPoint = p * 6;
                    p--;
                    console.log(curMaxPoint);
                    var myID = urlParams.get('id');
                    fetch(`../Data/clients.json`)
                        .then(res => res.json())
                        .then(data => {

                            var myClient = data.filter(client =>
                                client.id == myID);
                            // console.log(myClient);
                             curGM = myClient[0].kid.data.GM;
                             curFM = myClient[0].kid.data.FM;
                             curRL = myClient[0].kid.data.RL;
                             curEL = myClient[0].kid.data.EL;
                             curPS = myClient[0].kid.data.PS;
                            maxpoint = myClient[0].kid.data.maxpoint;
                        
                            //console.log(curGM);

                            console.log(curMaxPoint);
                            if (parseInt(curGM) < 100 || maxpoint < curMaxPoint) {
                                pushAllquestion("GM", p);
                                
                            }
                            if (parseInt(curFM) < 100 || maxpoint < curMaxPoint) {
                                pushAllquestion("FM", p);
                
                            }
                            if (parseInt(curRL) < 100 || maxpoint < curMaxPoint) {
                                pushAllquestion("RL", p);
         
                            }
                            if (parseInt(curEL) < 100 || maxpoint < curMaxPoint) {
                                pushAllquestion("EL", p);
       
                            }
                            if (parseInt(curPS) < 100 || maxpoint < curMaxPoint) {
                                pushAllquestion("PS", p);
                            }
                            curGM = curMaxPoint;
                            curFM = curMaxPoint;
                            curRL = curMaxPoint;
                            curEL = curMaxPoint;
                            curPS = curMaxPoint;
                            console.log(questionlist);
                            //curlistlenght=questionlist.length;
                            changeQuestion();
                        });
                    break;
                }

            }
        });

}

function pushAllquestion(tag, index) {
    switch (tag) {
        case "GM":
            for (var i = 0; i < questions[index].GM.length; i++) {
                var quizdata = {
                    "question": questions[index].GM[i],
                    "index": index,
                    "point": 6 / questions[index].GM.length
                }
                questionlist.push(quizdata);
            }
            break;
        case "FM":
            for (var i = 0; i < questions[index].FM.length; i++) {
                var quizdata = {
                    "question": questions[index].FM[i],
                    "index": index,
                    "point": 6 / questions[index].FM.length
                }
                questionlist.push(quizdata);
            }
            break;
        case "RL":
            for (var i = 0; i < questions[index].RL.length; i++) {
                var quizdata = {
                    "question": questions[index].RL[i],
                    "index": index,
                    "point": 6 / questions[index].RL.length
                }
                questionlist.push(quizdata);
            }
            break;
        case "EL":
            for (var i = 0; i < questions[index].EL.length; i++) {
                var quizdata = {
                    "question": questions[index].EL[i],
                    "index": index,
                    "point": 6 / questions[index].EL.length
                }
                questionlist.push(quizdata);
            }
            break;
        case "PS":
            for (var i = 0; i < questions[index].PS.length; i++) {
                var quizdata = {
                    "question": questions[index].PS[i],
                    "index": index,
                    "point": 6 / questions[index].PS.length
                }
                questionlist.push(quizdata);
            }
            break;
    }
}
