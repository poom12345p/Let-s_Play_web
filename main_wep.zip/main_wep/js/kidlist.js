var listbox = document.querySelector('#ss_elem_list');
var firstnamesrch = document.querySelector('#srchfirstname');
var lastnamesrch = document.querySelector('#srchlastname');
var nicknamesrch = document.querySelector('#srchnickname');
var urlParams = new URLSearchParams(location.search);
console.log(firstnamesrch);
console.log(listbox);


$('#searchbtn').click(function(){
  createlist();
  console.log(firstnamesrch.value);
});


/*function filter()
{
    let value=filterInput.value.toUpperCase();
   // console.log(value);
    let ul=document.querySelector('#names');
    let lis=document.querySelectorAll('li.collection-item');
    //console.log(lis);
    for(let i=0;i<lis.length;i++)
    {
        let a= lis[i].querySelector('a');
        if(a.innerHTML.toUpperCase().indexOf(value) >-1)
        {
            lis[i].style.display ='';
        }
        else
        {
            lis[i].style.display ='none';
        }
    }
   // console.log(lis);
}*/

function createlist()
{
    fetch(`../Data/clients.json`) 
    .then(res =>res.json())
    .then(data=>{
      var clients =[];
        listbox.innerHTML='';
        for(var i=0;i<data.length;i++)
        {
          if(firstnamesrch.value != "")
          {
            
              if(data[i].kid.firstname.indexOf(firstnamesrch.value) >-1)
              {
                clients.push(data[i])
                console.log(clients);
                continue;

              }
          }
          if(lastnamesrch.value != "")
          {
            if(data[i].kid.lastname.indexOf(lastnamesrch.value) >-1)
              {
                clients.push(data[i]);
                continue;
              }
          }
          if(nicknamesrch.value != "")
          {
            if(data[i].kid.nickname.indexOf(nicknamesrch.value) >-1)
              {
                clients.push(data[i]);
                continue;
              }
          }
        }
        if(firstnamesrch.value == ""&&lastnamesrch.value == ""&&nicknamesrch.value == "")
        {
          clients=data;
        }
      clients.sort((a,b) => (a.kid.firstname > b.kid.firstname) ? 1 : ((b.kid.firstname > a.kid.firstname) ? -1 : 0));
      if(urlParams.get('sort')=="age")
      {
        clients.sort((a,b) => (a.kid.age > b.kid.age) ? 1 : ((b.kid.age > a.kid.age) ? -1 : 0));
      }
        clients.forEach(client =>{
            listbox.innerHTML+=` 
            <li role="option">
            <a href="kidinfo.html?id=${client.id}" class="job-item d-block d-md-flex align-items-center  border-bottom fulltime">
              
              <div class="job-details h-100">
                <div class="p-3 align-self-center">
                  <h3>${client.kid.firstname} ${client.kid.lastname}</h3>
                  <div class="d-block d-lg-flex">
                    <div class="mr-3"></span>${client.kid.nickname}</div>
                  </div>
                </div>
              </div>
              <div class="job-category align-self-center">
                <div class="p-3">
                  <span class="text-warning p-2 rounded border border-warning" >อายุ ${client.kid.age} ปี</span>
                </div>
              </div>  
            </a>
          </li>
            `;
        })

    })
    .catch(err => console.log(err));
}