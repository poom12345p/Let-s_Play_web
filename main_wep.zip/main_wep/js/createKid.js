parentMaleCheck=document.querySelector("#parent-gender-male");
parentFemaleCheck=document.querySelector("#parent-gender-female");
kidMaleCheck=document.querySelector("#kid-gender-male");
kidFemaleCheck=document.querySelector("#kid-gender-female");
var cautiontag =document.querySelector("#caution");
var cautiontext =document.querySelector("#cautiontext");
cautiontag.style.visibility = "hidden";
//var myimg = document.querySelector('#blah');
//console.log(myimg);
parentMaleCheck.addEventListener ("change", CheckParentMale);
parentFemaleCheck.addEventListener ("change", CheckParentFemale);
kidMaleCheck.addEventListener ("change", CheckKidMale);
kidFemaleCheck.addEventListener ("change",CheckKidFemale);
console.log(location);
 console.log(location.host);
function CheckParentMale(event){
  if(parentMaleCheck.checked)
  parentFemaleCheck.checked=false;
  console.log("CheckParentMale");
}
function CheckParentFemale(event){
  if(parentFemaleCheck.checked)
  parentMaleCheck.checked= false;
}
function CheckKidFemale(event){
  if(kidFemaleCheck.checked)
  kidMaleCheck.checked =false;
}
function CheckKidMale(event){
  if(kidMaleCheck.checked)
  kidFemaleCheck.checked =false;
}



$(document).ready(function(){
    var client={
      "id":"",
      "username":"",
      "password":"",
      "address":"",
      "parentfirstname": "",
      "parentlastname": "",
      "parentgender": " ",
      "parentidentity": " ",
      "phone": " ",
      "email": " ",
      "kidfirstname": " ",
      "kidlastname": " ",
      "kidnickname": " ",
      "kidbrith":"",
      "kidgender": " ",
      "kidage": " ",
      "GM":"",
      "FM":"",
      "RL":"",
      "EL":"",
      "PS":"",
      "imgfile":""
    };

   
   
    $("#submit").click(function(){
      var caution="กรุณากรอก ";
      var pid=$("#parent-id").val();

      //var isOK=ture;
      if($("#email").val()=="") caution +="Email,";
      if($("#phone").val()=="") caution +="หมายเลขโทรศัพท์,";
      if($("#password").val()=="") caution +="password,";
      if($("#password").val()!= $("#re-password").val()) caution +="ยืนยันpasswordให้ตรงกัน,";
      if($("#parent-firstname").val()=="") caution +="ชื่อจริงผู้ปกครองม,";
      if($("#parent-lastname").val()=="") caution +="นามสกุลผู้ปกครอง,";
      if(pid.length <13) caution +="เลขบัตรประชาชน,";
      if($("#kid-firstname").val()=="") caution +="ชื่อเด็ก,";
      if($("#kid-lastname").val()=="") caution +="นามสกุลเด็ก,";
      if($("#kid-nickname").val()=="") caution +="ชื่อเล่นเด็ก,";
      if($("#kid-age").val()=="") caution +="วันเกิดเด็ก,";
      if(caution=="กรุณากรอก ")
      {
        client.username=$("#email").val();
        client.password=$("#password").val();
        client.email=$("#email").val();
        client.parentfirstname=$("#parent-firstname").val();
        client.parentlastname=$("#parent-lastname").val();
        if(document.querySelector("#parent-gender-male").checked){
            client.parentgender='ชาย';
        }
        else if(document.querySelector("#parent-gender-female").checked){
          client.parentgender='หญิง';
        }
        client.phone=$("#phone").val();
        client.parentidentity=$("#parent-id").val();
        client.address=$("#address").val();
        client.kidfirstname=$("#kid-firstname").val();
        client.kidlastname=$("#kid-lastname").val();
        client.kidnickname=$("#kid-nickname").val();
        //client.imgfile = myimg.src;
        console.log( client.imgfile);
        if(document.querySelector("#kid-gender-male").checked){
          client.kidgender='ชาย';
        }
        else if(document.querySelector("#kid-gender-female").checked){
          client.kidgender='หญิง';
        }
        client.kidbrith=$("#kid-dob").val();
        client.kidage=$("#kid-age").val();

        $.post(location.origin+"/creNewKid",client, function(data){
          if(data==='done')
            {
              alert("login success");
            }
        });
        location.replace(location.origin + `/newkidadded.html`)
      }
      else
      {
        cautiontag.style.visibility = "visible";
        cautiontext.innerHTML =caution;
        console.log(caution);
      }
    });
  });